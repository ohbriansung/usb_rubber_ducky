John The Riper Jumbo Version 1.8.0-1 precompiled for Raspbian Jessie
====================================================================

Target OS version: 

    Linux raspberrypi 4.4.34+ #930 Wed Nov 23 15:12:30 GMT 2016 armv6l GNU/Linux

John The Ripper version:

    John the Ripper password cracker, version 1.8.0-jumbo-1_omp [linux-gnueabihf 32-bit armv6l-autoconf]
    Copyright (c) 1996-2014 by Solar Designer and others
    Homepage: http://www.openwall.com/john/


NetNTLMv2 benchmark on Pi Zero:

    Warning: OpenMP is disabled; a non-OpenMP build may be faster
    Benchmarking: netntlmv2, NTLMv2 C/R [MD4 HMAC-MD5 32/32]... DONE
    Many salts:	105411 c/s real, 106455 c/s virtual
    Only one salt:	76039 c/s real, 76039 c/s virtual

