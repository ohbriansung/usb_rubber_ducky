DISCLAIMER
==========

**P4wnP1** is dedicated to penetration testers, redteamers and InfoSec personal.
P4wnP1 is a Proof of Concept and should be used for authorized testing and/or 
educational purposes only. The only exception is using it against devices
or a network, owned by yourself.

I take no responsibility for the abuse of P4wnP1 or any information given in
the related documents. 

**I DO NOT GRANT PERMISSIONS TO USE P4wnP1 TO BREAK THE LAW.**

As P4wnP1 is meant as a Proof of Concept, it is likely that bugs occur.
I disclaim any warranty for P4wnP1, it is provided "as is".
